Welcome to Seagull!

Seagull is a free and Open Source (GPL) multi-protocol 
traffic generator test tool. 
Primary aimed at IMS protocols (and thus being the perfect 
complement to SIPp (http://sipp.sourceforge.net) for IMS testing), 
Seagull is a powerful traffic generator for functional, load, 
endurance, stress and performance tests for almost any kind of protocol.

More information: http://gull.sourceforge.net/
